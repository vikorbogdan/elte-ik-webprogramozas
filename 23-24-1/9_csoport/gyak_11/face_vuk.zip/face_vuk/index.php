<?php

$users = json_decode(file_get_contents("users.json"), true);


// Néhány PHP verzió nem    tartalmazza az str_contains függvényt, így itt definiálva van. (Figyelmen kívül hagyhatod.)
if (!function_exists('str_contains')) {
    function str_contains($haystack, $needle)
    {
        return $needle !== '' && mb_strpos($haystack, $needle) !== false;
    }
}


// 1. Kérdezd le a keresőkifejezést a GET Paraméterek közül! (1 pont)
$keyword = "";
if (isset($_GET["search"])) {
    $keyword = $_GET["search"];
}
// var_dump($keyword);

// 2. Ha van megadva keresőkifejezés az URL-ben, listázd ki csak azokat a felhasználókat, amelyek neve tartalmazza a keresőkifejezést!
//    A keresés ne tegyen különbséget kis- és nagy betűk között.
//    (Tipp: A megoldáshoz az str_contains illetve strtolower függvényeket használhatod.) (1 pont)
// Pl. A "ró" kifejezésre listázza ki a "Róka Úr" illetve "Róka Koma" felhasználókat.

$filtered_users = [];
foreach ($users as $user) {
    if (str_contains(strtolower($user["name"]), strtolower($keyword))) {
        $filtered_users[] = $user;
    }
}
// 3. Ha nincs megadva semmilyen query az url-ben (Nincsenek GET paraméterek) listázza ki az összes felhasználót az oldal! (1 pont)
// (A navigációs sávon található FaceVuk Feliratra kattintva)


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FaceVuk</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <nav>
        <a href="?">
            <h1>FaceVuk</h1>
        </a>
        <div style="margin-right: 20px;">
            <a style="color: white;" href="login.php">
                Register
            </a>
            <a style="color: white;" href="login.php">
                Log In
            </a>
        </div>
        <form method="get">
            <input type="text" name="search" id="search">
            <button type="submit">
                <img src="./search-icon.svg" alt="Search">
            </button>
        </form>
    </nav>
    <ul id="results">
        <?php foreach ($filtered_users as $user) : ?>
            <li>
                <img src="<?= $user["img"] ?>" alt="" />
                <h2><?= $user["name"] ?></h2>
            </li>
        <?php endforeach; ?>
    </ul>
</body>

</html>